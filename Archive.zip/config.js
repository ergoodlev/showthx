// Email configuration for GratituGram
// IMPORTANT: Do not commit this file to git! Add to .gitignore

export const SENDGRID_CONFIG = {
  API_KEY: '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',
  FROM_EMAIL: 'ericgoodlev@gmail.com', 
  FROM_NAME: 'GratituGram',
};

// IMPORTANT: You need to verify your sender email in SendGrid dashboard:
// 1. Go to https://app.sendgrid.com/settings/sender_auth/senders
// 2. Click "Create New Sender"
// 3. Fill in your details with the email you want to send FROM
// 4. Verify the email
// 5. Update FROM_EMAIL above with that verified email
